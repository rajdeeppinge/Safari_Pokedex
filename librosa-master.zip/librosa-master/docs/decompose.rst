.. _decompose:

.. automodule:: librosa.decompose
