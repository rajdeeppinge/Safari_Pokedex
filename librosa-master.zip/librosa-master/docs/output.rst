.. _output:

.. automodule:: librosa.output
