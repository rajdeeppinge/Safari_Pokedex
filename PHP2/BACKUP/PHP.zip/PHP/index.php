<html>
   <head>
      <title>Online PHP Script Execution</title>      
   </head>
   
   <body>
      
 

         <?php
         $filename = "tmp.txt";
         $file = fopen( $filename, "r" );
         
         if( $file == false ) {
            echo ( "Error in opening file" );
            exit();
         }
         
         $filesize = filesize( $filename );
         $filetext = fread( $file, $filesize );
         fclose( $file );
         
      
         echo ( "<pre>$filetext</pre>" );
      ?>



</body>


</html>




   </body>
</html>
